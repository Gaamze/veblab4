package mk.finki.ukim.mk.lab.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class WebSecurityConfig {
    private final PasswordEncoder passwordEncoder;


    public WebSecurityConfig(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

//bu ceist isley loginim
    //artanin sekil yeptimmi yapay denied acces
    @Bean //httpecurity
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests((requests) -> requests
                        .requestMatchers("/", "/events", "/assets/**", "/register")
                        .permitAll()
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                     //   .requestMatchers("/events/add", "/events/edit/**")
                       // .hasAnyRole("ADMIN")
                        //.requestMatchers("/events/delete/**")
                        //.hasRole("ADMIN")
                        .anyRequest()
                        .authenticated()
                )
                //.httpBasic(Customizer.withDefaults())
                .formLogin((form) -> form
                        .loginPage("/login")
                        .permitAll()
                      //  .failureUrl("/login?error=BadCredentials")
                        .defaultSuccessUrl("/events", true)
                )
                .logout((logout) -> logout
                        .logoutUrl("/logout")
                        .clearAuthentication(true)
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                        .logoutSuccessUrl("/events")

                       // .exceptionHandling((ex) -> ex
                         //       .accessDeniedPage("/access_denied")
                );
//                .csrf(AbstractHttpConfigurer::disable)
//                .authorizeHttpRequests((requests) -> requests
//                        .requestMatchers("/","/home","/assets/**","/register", "/login","/events","/events/edit/{id}")
//                        .permitAll()
//                        .anyRequest()
//                        .hasRole("ADMIN"))
//                .formLogin(form->form
//                        .permitAll()
//                        .defaultSuccessUrl("/events"))
//                .logout(logout->logout
//                        .logoutUrl("/logout")
//                        .permitAll()
//                        .logoutSuccessUrl("/events"));

        return http.build();
    }

@Bean
    public UserDetailsService userDetailsService() {
        UserDetails  user1= User.builder()
                .username("gamze.mustafa")
                .password(passwordEncoder.encode("gm"))
                .roles("ADMIN")
                .build();
        UserDetails  user2= User.builder()
                .username("finki.user")
                .password(passwordEncoder.encode("fu"))
                .roles("USER")
                .build();
        return new InMemoryUserDetailsManager(user1, user2);
        //bureyeka calisti user em config le ama lofinde bad credentials verdi
    }



}

//beanlari koydumi isledi login ama enetrde gene verdi htm codi ekrana