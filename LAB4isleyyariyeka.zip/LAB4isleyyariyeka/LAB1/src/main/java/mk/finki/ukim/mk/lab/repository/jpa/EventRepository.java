package mk.finki.ukim.mk.lab.repository.jpa;

import mk.finki.ukim.mk.lab.model.Event; //referriia edey event modele
import org.springframework.data.jpa.repository.JpaRepository;

//import org.springframework.stereotype.Repository;//anotacijaj kullanmak icin

import java.util.List;
import java.util.Optional;


//@Repository //repo repoyA depedensiy bir turli hallettri
public interface EventRepository extends JpaRepository<Event, Long> {

}





















