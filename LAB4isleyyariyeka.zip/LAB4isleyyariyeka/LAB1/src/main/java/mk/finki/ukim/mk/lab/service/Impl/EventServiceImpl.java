
package mk.finki.ukim.mk.lab.service.Impl;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.jpa.EventRepository;
import mk.finki.ukim.mk.lab.repository.jpa.LocationRepository;
import mk.finki.ukim.mk.lab.repository.inmemory.InMemoryEventRepository;
import mk.finki.ukim.mk.lab.repository.inmemory.InMemoryLocationRepository;
import mk.finki.ukim.mk.lab.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EventServiceImpl implements EventService {
    private final EventRepository eventRepository;
    private final LocationRepository locationRepository;

    public EventServiceImpl(EventRepository eventRepository, LocationRepository locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;
    }

    @Override
    public List<Event> listAll() {
        return eventRepository.findAll();
    }

    @Override
    public void saveEvent(String eventName, String description, double popularityScore, Long id) {
        Location location = locationRepository.findById(id).get();
        eventRepository.save(new Event(eventName, description, popularityScore, location));
    }
    @Override
    public Optional<Event> findById(long id) {
        return eventRepository.findById(id);
    }
    @Override
    public List<Event> searchEvents(String text, int score) {
        return eventRepository.findAll().stream()
                .filter(event -> (event.getName().toLowerCase().contains(text.toLowerCase()) ||
                        event.getDescription().toLowerCase().contains(text.toLowerCase())) &&
                        event.getPopularityScore() >= score)
                .collect(Collectors.toList());
    }

    @Override
    public Event getEventById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Event with id " + id + " not found"));
    }

        @Override
         public void editEvent(String eventname, String description, double popularityScore, Long eventId, Long locationId) {
        Event event = eventRepository.findById(eventId).get();
        Location location = locationRepository.findById(locationId).get();
        event.setName(eventname);
        event.setDescription(description);
        event.setPopularityScore(popularityScore);
        event.setLocation(location);

        eventRepository.save(event);
    }

        @Override
        public void deleteById(Long id) {
        eventRepository.deleteById(id);
    }
}
